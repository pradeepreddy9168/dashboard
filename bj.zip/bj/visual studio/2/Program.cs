﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
            List<Message> ls = new List<Message>();
            Console.WriteLine("Enter the name of the Chat:");
            string s = Console.ReadLine();
            Chat c = new Chat(s, new List<Message>());
            while (true)
            {
                Console.WriteLine("1.Add Message\n2.Delete Message\n3.Display Messages\n4.Exit\nEnter your choice:");
                //Console.WriteLine("Enter your choice:");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                {
                    string x = Console.ReadLine();
                    Message st = Message.CreateMessage(x);
                    c.MessageList.Add(st);
                    Console.WriteLine("Message successfully added");
                }
                else if (ch == 2)
                {
                    Console.WriteLine("Enter the id of the message to be deleted:");
                    long y = long.Parse(Console.ReadLine());
                    bool i = c.RemoveMessage(y);
                    if (i)
                        Console.WriteLine("Message successfully deleted");
                    else
                        Console.WriteLine("Message not found in the Chat");
                }
                else if (ch == 3)
                {
                    //Class cl = new Class();
                    c.DisplayMessages();
                }
                else if (ch == 4)
                    return;
                else
                    return;
            }
        }
    }

