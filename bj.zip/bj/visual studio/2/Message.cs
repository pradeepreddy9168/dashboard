﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Message
    {
        long _id;

        public long Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _from;

        public string From
        {
            get { return _from; }
            set { _from = value; }
        }
        long _mobileNumber;

        public long MobileNumber
        {
            get { return _mobileNumber; }
            set { _mobileNumber = value; }
        }
        string _content;

        public string Content
        {
            get { return _content; }
            set { _content = value; }
        }
        double _size;

        public double Size
        {
            get { return _size; }
            set { _size = value; }
        }
        DateTime _postedDate;

        public DateTime PostedDate
        {
            get { return _postedDate; }
            set { _postedDate = value; }
        }
        public Message()
        {

        }
        public Message(long _id, string _from, long _mobileNumber, string _content, double _size, DateTime _postedDate)
        {
            this._id = _id;
            this._from = _from;
            this._mobileNumber = _mobileNumber;
            this._content = _content;
            this._size = _size;
            this._postedDate = _postedDate;
        }

        public static Message CreateMessage(string details)
        {
            string[] s = details.Split(',');
            Message m = new Message(long.Parse(s[0]), s[1], long.Parse(s[2]), s[3], double.Parse(s[4]), DateTime.ParseExact(s[5], "dd-MM-yyyy", null));
            return m;
        }

        public override string ToString()
        {
            return string.Format("{0,-5} {1,-8} {2,-15} {3,-45} {4,-5} {5}", Id, From, MobileNumber, Content, Size.ToString("0.0"), PostedDate.ToString("dd-MM-yyyy"));
        }

        //public override bool Equals(object obj)
        //{
        //    Message m = (Message)obj;
        //    if (m.From.Equals(From, StringComparison.InvariantCultureIgnoreCase) && m.MobileNumber.Equals(MobileNumber))
        //        return true;
        //    else
        //        return false;
        //}
    }

