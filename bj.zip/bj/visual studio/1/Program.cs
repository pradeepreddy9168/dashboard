﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        List<Message> li = new List<Message>();
        for (int index = 1; index <= 2; index++)
        {
            Console.WriteLine("Enter message " + (index) + " details:");
            string[] s = Console.ReadLine().Split(',');
            Message me = new Message(long.Parse(s[0]), s[1], long.Parse(s[2]), s[3], double.Parse(s[4]), DateTime.ParseExact(s[5], "dd-MM-yyyy", null));
            li.Add(me);
        }

        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine("\nMessage {0}", i + 1);
            Console.WriteLine(li[i].ToString());
        }

        if (li[0].Equals(li[1]))
        {
            Console.WriteLine("\nMessage 1 is same as Message 2");
        }
        else
        {
            Console.WriteLine("\nMessage 1 and Message 2 are different");
        }
    }
}