﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class MessageBO
    {
        public List<Message> FindMessage(List<Message> messageList, string content)
        {
            List<Message> lm = new List<Message>();
            foreach (var item in messageList)
            {
                if (item.Content.ToLower().Contains(content.ToLower()) || item.Content.Contains(content) || item.Content.ToUpper().Contains(content.ToUpper()))
                    lm.Add(item);
            }
            return lm;
        }

        public List<Message> FindMessage(List<Message> messageList, DateTime postedDate)
        {
            List<Message> lm = new List<Message>();
            foreach (var item in messageList)
            {
                if (item.PostedDate.Equals(postedDate))
                    lm.Add(item);
            }
            return lm;
        }
    }

