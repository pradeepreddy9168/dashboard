﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class PostedDateComparer:IComparer<Message>
{
    //fill code here
    public int Compare(Message x, Message y)
    {
        return x.PostedDate.CompareTo(y.PostedDate);
    }
}