﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mfrp
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_ServerClick(object sender, EventArgs e)
        {
            string username = Request.Form["uname"];
            string pasword = Request.Form["password"];
           
       
            bool status = LoginDAO.validate_Password(username, pasword);
            if (status)
            {
                Response.Redirect("Dashboard.aspx");
            }
            else
            {
                
                Label1.Text = "Invalid username and password";
                Label1.Visible = true;
            }

        }
    }
}