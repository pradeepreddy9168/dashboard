﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp.pages
{
    public partial class Facet_Tsg : System.Web.UI.Page
    {
        DataSet ds;
        protected void Page_Load(object sender, EventArgs e)
        {
            //SqlConnection cn = new SqlConnection();
            //cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            //SqlCommand sc = new SqlCommand("select * from facets", cn);
            //SqlDataAdapter da = new SqlDataAdapter(sc);
            //DataSet ds = new DataSet();
            //cn.Open();
            //da.Fill(ds);
            //cn.Close();
            ds = FaceDao.load_GridView();
            GridView1.DataSource = ds.Tables[0];

           // GridView1.EnableSortingAndPagingCallbacks = true;
            GridView1.DataBind();
            GridView1.Visible = true;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            int ID = 0;
            if (TextBox1.Text == "")
            {
                ID = 0;
            }
            else
            {
                ID = int.Parse(TextBox1.Text);
            }
            DataSet ds = FaceDao.load_id(ID);

            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
            //GridView1.Visible = false;
            //int ID= int.Parse(TextBox1.Text);
            //DataSet ds= FaceDao.load_id(ID);
            //GridView1.DataSource = ds.Tables[0];
            //GridView1.DataBind();
            //GridView1.Visible = true;
        }

        protected void txtPickupDate_TextChanged(object sender, EventArgs e)
        {

           // DateTime date = DateTime.ParseExact(TextBox6.Text.ToString(),"MM/dd/yyyy",null);
            DateTime date = DateTime.Parse(txtPickupDate.Text.ToString());

            GridView1.Visible = false;
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select * from facets where order_date=@date", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@date", date);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
        }

    
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.DataSource = ds.Tables[0];

          
            GridView1.DataBind();
            GridView1.Visible = true;
            GridView1.PageIndex = e.NewPageIndex;
           
            
        }
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string s = DropDownList2.SelectedValue.ToString();
            DataSet ds1 = FaceDao.load_filetype(s);
            GridView1.DataSource = ds1.Tables[0];
            GridView1.DataBind();
            GridView1.Visible = true;
            
        }
        //protected void Date_Selected(object sender, EventArgs e)
        //{
        //    TextBox6.Text = Calendar1.SelectedDate.ToShortDateString();
        //Calendar1.Visible = false;
        //}
        //protected void show_date(object sender, EventArgs e)
        //{
        //    if (Calendar1.Visible == true) Calendar1.Visible = false;
        //    else
        //    {
        //        Calendar1.Visible = true;
        //        TextBox6.Text = "";
        //    }
           
        //}
    }
}