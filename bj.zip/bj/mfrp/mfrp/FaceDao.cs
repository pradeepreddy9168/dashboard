﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace mfrp
{
    public class FaceDao
    {
        public  void connection()
        {
        }
        public static  DataSet load_GridView()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select * from facets", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }
        public static DataSet load_id(int id )
        {

            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select * from facets where invoice_number=@iid", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@iid", id);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;
        }




        public void load_OrderDate()
        {
          

        }



        public static DataSet load_filetype(string type)
        {
            string x = "";
            if (type == "shipped")
            {
                x = "a";
            }
            else if (type == "notshipped")
            {
                x = "b";
            }
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = ConfigurationManager.ConnectionStrings["mycn"].ConnectionString;
            SqlCommand sc = new SqlCommand("select * from facets where file_type=@iid", cn);
            SqlDataAdapter da = new SqlDataAdapter(sc);
            sc.Parameters.AddWithValue("@iid", x);
            DataSet ds = new DataSet();
            cn.Open();
            da.Fill(ds);
            cn.Close();
            return ds;

        }


    }
}